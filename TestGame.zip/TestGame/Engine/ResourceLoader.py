import os
import pygame
import pytmx
import time

from pytmx.pytmx import TiledMap


class CursorLoader(object):
    def __init__(self):
        self.image = None

    def load_cursor(self, filename: str):
        self.image = pygame.image.load(filename)
        return self.image


class ResourceLoader(object):
    def __init__(self):
        self.resources = {}
        for item in os.scandir("assets"):
            if item.is_dir():
                self.resources[item.name] = {}
                self.load_tree(item.name, item.path)

    def get_resource(self, resource_type: str, file_name: str) -> str:
        return self.resources[resource_type][file_name]

    def load_resource_type(self, path: str) -> None:
        self.resources[path] = {}
        self.load_tree(path, "./assets/" + path)

    def get_file_name(self, path: str) -> str:
        # get file name from relative path
        return path[path.rfind('\\') + 1: path.rfind('.')]

    def load_resource(self, resource_type: str, path: str) -> None:
        # load resource into relative path
        self.resources[resource_type][self.get_file_name(path)] = path

    def load_tree(self, resource_type: str, path: str) -> None:
        for item in os.scandir(path):
            if item.is_file():
                if item.path.endswith(".png") or item.path.endswith(".tmx"):
                    self.load_resource(resource_type, item.path)
                    print("Loaded resource: " + item.name +
                          " at point: " + resource_type)
            else:
                self.load_tree(resource_type, item.path)


class MapLoader(object):
    def __init__(self, path_to_tmx: str):
        self.__map = pytmx.load_pygame(path_to_tmx)

    def get_width(self) -> int:
        return self.__map.width

    def get_height(self) -> int:
        return self.__map.height

    def generate_data(self) -> tuple[int, int, int]:
        return (len(self.__map.layers), self.get_width(), self.get_height())

    def get_map(self) -> TiledMap:
        return self.__map
