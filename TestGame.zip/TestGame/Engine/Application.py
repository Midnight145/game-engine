import Engine.Entity
from Engine.UI.Element import Window
from Engine.Logger import Logger
from pygame import display, event, camera
import pygame
import time

import Engine
from Engine.ResourceLoader import *
from Engine.Input import InputManager
from Engine.Camera import Camera


class Application(object):
    def __init__(self, window_name: str, window_size: tuple):
        self.screen = pygame.display.set_mode(window_size)
        display.set_caption(window_name)

        self.input_manager = InputManager()
        self.resource_manager = ResourceLoader()
        display.set_icon(pygame.image.load(
            self.resource_manager.get_resource("textures", "tavern")))
        self.scene = None
        self.camera = Camera(
            (self.screen.get_width() / 32, self.screen.get_height() / 32))

        self.windows = {
            "inventory": Window("inventory", 0, 0, self.resource_manager)
        }

        self.logger = Logger(True, "output.log")

        self.reserved_actions = list[Engine.Entity.EntityAction]()

    def load_scene(self, scene: Engine.Scene):
        self.scene = scene
        self.camera.set_scene_dimensions(
            scene.map.width, scene.map.height)

    def __call__(self):
        self.running = True

        cursor_locations = []
        for y in range(int(self.screen.get_height() / 32)):
            for x in range(int(self.screen.get_width() / 32)):
                cursor_locations.append(pygame.Rect(x * 32, y * 32, 32, 32))

        while self.running:
            self.screen.fill((0, 0, 0))

            self.input_manager.clear_buttons()
            self.input_manager.clear_keys()
            for system_event in event.get():
                if system_event.type == pygame.QUIT:
                    self.running = False
                if system_event.type == pygame.KEYDOWN:
                    self.input_manager.press_key(system_event.key)
                if system_event.type == pygame.MOUSEBUTTONDOWN:
                    self.input_manager.press_button(system_event.button)

            for action in self.reserved_actions:
                if action.checker():
                    action.action()

            # broken
            if self.scene.update_camera:
                self.camera.camera_bounds = pygame.Rect(
                    self.scene.map.allies['player'].properties['x'].value / 32,
                    self.scene.map.allies['player'].properties['y'].value / 32,
                    self.camera.camera_bounds.width,
                    self.camera.camera_bounds.height
                )
                print("Moved camera to (" + str(self.camera.camera_bounds.x) +
                      ", " + str(self.camera.camera_bounds.y) + ")")
                self.scene.update_camera = False

            window_shown = False
            for window in self.windows.values():
                if window.properties['visibility'] == "True":
                    window_shown = True

            if not window_shown:
                self.scene.update(
                    self.camera.camera_bounds.topleft, self.resource_manager,
                    self.input_manager)

            self.screen.blit(self.camera.get_viewport(
                self.scene), (0, 0))  # TODO: fix this

            # TODO: fix this
            for window in self.windows.values():
                window.actions['get_sprite'].action(window).draw(self.screen)

            pos = pygame.mouse.get_pos()
            for rect in cursor_locations:
                if rect.collidepoint(pos):
                    new_pos = (rect.x / 32, rect.y / 32)
                    break

            display.flip()

    def __del__(self):
        pygame.quit()
        self.logger.logfile.close()
