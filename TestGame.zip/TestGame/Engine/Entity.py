import pygame
import os

from typing import Any

import Engine.ScriptParser as parser

from Engine import Scene
from Engine import ResourceLoader


class EntityProperty(object):
    def __init__(self, value_type, value):
        self.type = value_type
        self.value = value

    @staticmethod
    def translateType(type: str, convertable: Any):
        if type == "int":
            return int(convertable)
        elif type == "list":
            return convertable
        elif type == "bool":
            return True if convertable[0] == "True" else False


class EntityAction(object):
    def __init__(self, checker, action, continuous: EntityProperty):
        super().__init__()
        self.checker = checker
        self.action = action
        self.continuous = continuous


class Entity(object):
    def __init__(self, name: str, x: int, y: int, images: list, resources: ResourceLoader.ResourceLoader, properties: dict, actions: dict) -> None:
        self.properties = {}
        if os.path.exists("./assets/entities/" + name + "_properties.pl"):
            properties_file = open("./assets/entities/" +
                                   name + "_properties.pl", 'r')
            self.properties = parser.ParsePropertyString(
                properties_file.readlines(), resources)

        self.actions = {}
        if os.path.exists("./assets/entities/" + name + "_actions.pl"):
            actions_file = open("./assets/entities/" +
                                name + "_actions.pl", 'r')
            self.actions = parser.ParseActionString(
                actions_file.readlines()
            )

        if 'name' not in self.properties:
            self.properties['name'] = EntityProperty("str", name)

        if 'x' not in self.properties:
            self.properties['x'] = EntityProperty("int", x * 32)
        if 'y' not in self.properties:
            self.properties['y'] = EntityProperty('int', y * 32)
        if 'width' not in self.properties:
            self.properties['width'] = EntityProperty("int", 32)
        if 'height' not in self.properties:
            self.properties['height'] = EntityProperty("int", 32)

        self.properties['sprite'] = EntityProperty(
            "misc", pygame.sprite.OrderedUpdates()
        )
        self.properties['sprites'] = EntityProperty(
            "list", list[pygame.sprite.Sprite]()
        )

        for resource in self.properties['resources'].value if len(images) == 0 else images:
            if isinstance(resource, pygame.Surface):
                sprite = pygame.sprite.Sprite(
                    self.properties['sprite'].value)
                sprite.image = resource
                sprite.rect = pygame.Rect(
                    self.properties['x'].value if 'x' in self.properties else x,
                    self.properties['y'].value if 'y' in self.properties else y,
                    self.properties['width'].value if "width" in self.properties else 32,
                    self.properties['height'].value if "height" in self.properties else 32
                )
                self.properties['sprites'].value.append(sprite)
            else:
                sprite = pygame.sprite.Sprite(
                    self.properties['sprite'].value)
                sprite.image = pygame.image.load(
                    resources.get_resource("textures", resource)
                )
                sprite.rect = pygame.Rect(
                    self.properties['x'].value if 'x' in self.properties else x,
                    self.properties['y'].value if 'y' in self.properties else y,
                    self.properties['width'].value if "width" in self.properties else 32,
                    self.properties['height'].value if "height" in self.properties else 32
                )
                self.properties['sprites'].value.append(sprite)

    def check_actions(self, scene: Scene) -> bool:
        for checker in self.actions.values():
            if checker.checker(self, scene):
                return True

        return False

    def perform_actions(self, scene: Scene) -> None:
        to_delete = []

        for key, item in self.actions.items():
            if item.checker(self, scene):
                item.action(self, scene)
                if not item.continuous:
                    to_delete.append(key)

        for i in to_delete:
            del self.actions[i]
