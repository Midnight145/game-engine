import Engine.ScriptParser as Parser
import Engine
import abc
import os.path as path
import pygame

from Engine.ResourceLoader import ResourceLoader
import Engine.Entity as Entity


class Window(object):
    def __init__(self, name: str, x: int, y: int, resources: ResourceLoader) -> None:
        self.properties = {}
        if path.exists("./assets/ui/" + name + "_properties.we"):
            properties_file = open("./assets/ui/" +
                                   name + "_properties.we", 'r')
            self.properties = Parser.ParsePropertyString(
                properties_file.readlines(),
                resources)

        self.actions = {}
        if path.exists("./assets/ui/" + name + "_actions.we"):
            actions_file = open("./assets/ui/" +
                                name + "_actions.we", 'r')
            self.actions = Parser.ParseActionString(
                actions_file.readlines())

        if 'x' not in self.properties:
            self.properties['x'] = Entity.EntityProperty(
                "int", x
            )
        if 'y' not in self.properties:
            self.properties['y'] = Entity.EntityProperty(
                "int", y
            )

        self.properties['sprite'] = Entity.EntityProperty(
            "misc", pygame.sprite.OrderedUpdates())
        self.properties['sprites'] = Entity.EntityProperty(
            "list", list[pygame.sprite.Sprite]()
        )
        for resource in self.properties['resources'].value:
            sprite = pygame.sprite.Sprite(self.properties['sprite'].value)
            sprite.image = pygame.image.load(
                resources.get_resource("textures", resource)
            )
            sprite.rect = pygame.Rect(
                self.properties['x'].value,
                self.properties['y'].value,
                self.properties['width'].value,
                self.properties['height'].value
            )
            self.properties['sprites'].value.append(sprite)
