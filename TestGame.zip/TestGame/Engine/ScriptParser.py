from Engine.Scene import Scene
from Engine.ResourceLoader import ResourceLoader
import Engine.UI.Element as UI
import pygame
import Engine.Entity
import Engine.Entity as Entity

def default_checker() -> bool:
    return True


def can_move_up(entity, scene: Scene) -> bool:
    return entity.properties['can_move_up'].value


def move_up(entity, scene: Scene) -> None:
    if scene.move_entity(entity, (0, -1 * 32)):
        print('moved up')
    entity.properties['can_move_up'].value = False


def can_move_left(entity, scene: Scene) -> bool:
    return entity.properties['can_move_left'].value


def move_left(entity, scene: Scene) -> None:
    if scene.move_entity(entity, (-1 * 32, 0)):
        print("move left")
    entity.properties['can_move_left'].value = False


def can_move_down(entity, scene: Scene) -> bool:
    return entity.properties['can_move_down'].value


def move_down(entity, scene: Scene) -> None:
    if scene.move_entity(entity, (0, 1 * 32)):
        print('moved down')
    entity.properties['can_move_down'].value = False


def can_move_right(entity, scene: Scene) -> bool:
    return entity.properties['can_move_right'].value


def move_right(entity, scene: Scene) -> None:
    if scene.move_entity(entity, (1 * 32, 0)):
        print("move right")
    entity.properties['can_move_right'].value = False

def can_move(entity, scene: Scene) -> bool:
    return entity.properties['can_move'].value

def move(entity, scene: Scene) -> None:
    delta = entity.properties['move_queue'].value.pop(0)
    scene.move_entity(entity, )


def toggle_visibility(window):
    if window.properties['visibility'].value:
        window.properties['visibility'].value = False
    else:
        window.properties['visibility'].value = True
    if "child_nodes" in window.properties:
        for row in window.properties['child_nodes'].value:
            for child in row:
                child.actions['toggle_visibility'].action(child)


def get_sprite(window):
    if window.properties['visibility'].value:
        retcode = pygame.sprite.OrderedUpdates()
        retcode.add(window.properties['sprite'].value)
        if 'child_nodes' in window.properties:
            for row in window.properties['child_nodes'].value:
                for child in row:
                    if child.properties['visibility'].value:
                        retcode.add(child.actions['get_sprite'].action(child))
        return retcode
    else:
        return pygame.sprite.OrderedUpdates()


def get_action(name: str):
    try:
        return globals()[name]
    except:
        return None


def ParsePropertyString(input: list[str], resource_manager: ResourceLoader) -> dict[str, Engine.Entity.EntityProperty]:
    properties = dict[str, Engine.Entity.EntityProperty]()
    for line in input:
        
        line_args = line.split()
        print(line_args)
        property = Engine.Entity.EntityProperty("", "")
        property.type = line_args[1]
        if line_args[0] == "child_nodes":
            if line_args[1] == "list":
                property.value = list[UI.Window]()
                for arg in line_args[2:]:
                    property.value.append(
                        UI.Window(
                            arg, len(property.value) * (property.value[0].properties['width'].value if len(
                                property.value) > 0 else 0), 2, resource_manager
                        )
                    )
            elif line_args[1] == "box":
                property.value = list[list[UI.Window]]()
                item_queue = []
                for arg in line_args[4:]:
                    item_queue.append(arg)
                for y in range(int(line_args[3])):
                    property.value.append(list[UI.Window]())
                    for x in range(int(line_args[2])):
                        property.value[y].append(
                            UI.Window(
                                item_queue.pop(0),
                                x * property.value[0][0].properties['width'].value  if len(property.value[0]) > 0 else 0 + 1,
                                y * property.value[0][0].properties['height'].value if len(property.value[0]) > 0 else 0 + 1,
                                resource_manager
                            )
                        )
                pass
            elif line_args[1] == "stack":
                property.value = list[UI.Window]()
                for arg in line_args[2:]:
                    property.value.append(
                        UI.Window(
                            arg, 0, 0, resource_manager
                        )
                    )
            else:
                raise Exception("Bad argument " + line_args[1])
        elif line_args[0] == "resources":
            if line_args[1] == "list":
                property.value = list[str]()
                for arg in line_args[2:]:
                    property.value.append(
                        arg
                    )
            else:
                raise Exception("Bad argument " + line_args[1])
        else:
            property.value = Engine.Entity.EntityProperty.translateType(
                property.type, line_args[2])
        properties[line_args[0]] = property

    if "resources" not in properties:
        properties['resources'] = []
    return properties


def ParseActionString(input: list[str]) -> dict[str, Engine.Entity.EntityAction]:
    actions = dict[str, Engine.Entity.EntityAction]()
    for line in input:
        line_args = line.split()
        action = Engine.Entity.EntityAction("", "", Engine.Entity.EntityProperty(
            "bool", Engine.Entity.EntityProperty.translateType("bool", "False")))
        action.checker = get_action(line_args[1])
        action.action = get_action(line_args[2])
        action.continuous = Engine.Entity.EntityProperty("bool", line_args[3])
        actions[line_args[0]] = action
    return actions
