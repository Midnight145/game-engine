from Engine.ResourceLoader import MapLoader
from Engine.Scene import Scene
import pygame


class Camera(object):
    def __init__(self, camera_size: tuple):
        self.camera_bounds = pygame.Rect(
            0, 0, camera_size[0], camera_size[1]
        )

    def set_scene_dimensions(self, width, height):
        self.scene_width = width
        self.scene_height = height

    def get_viewport(self, scene: Scene):
        return scene.render().subsurface(
            0 if self.camera_bounds.x * 32 - self.camera_bounds.width * 16 < 0 else self.scene_width * 32 - self.camera_bounds.width * 32 if self.camera_bounds.x * 32 +
            self.camera_bounds.width * 32 > self.scene_width * 32 else self.camera_bounds.x * 32 - self.camera_bounds.width * 16 + 16,
            0 if self.camera_bounds.y * 32 - self.camera_bounds.height * 16 < 0 else self.scene_height * 32 - self.camera_bounds.height * 32 if self.camera_bounds.y * 32 +
            self.camera_bounds.height * 32 > self.scene_height * 32 else self.camera_bounds.y * 32 - self.camera_bounds.height * 16 + 16,
            self.camera_bounds.width * 32,
            self.camera_bounds.height * 32
        )
