from Engine.ResourceLoader import ResourceLoader
import Engine.Entity as Entity
from pytmx.pytmx import TiledMap


class World():
    def __init__(self, layer_amount: int, width: int, height: int):
        self.layers = layer_amount
        self.width = width
        self.height = height
        self.allies = {}
        self.enemies = {}
        self.obsicals = {}

        arr = list[list[list[Entity.Entity]]]()
        for z in range(layer_amount):
            arr.append(list[list[Entity.Entity]]())
            for y in range(height):
                arr[z].append(list[Entity.Entity]())
                for x in range(width):
                    arr[z][y].append(0)
        self.array = arr

    def __call__(self, layer: int, row=None):
        if row is None:
            return self.array[layer]
        else:
            return self.array[layer][row]

    def insert(self, layer, row, index, data):
        try:
            self.array[layer][row][index] = data
        except IndexError:
            return

    def write_map_data(self, system_map: TiledMap, resource_loader: ResourceLoader):
        for layer in range(self.layers):
            for y in range(self.height):
                for x in range(self.width):
                    try:
                        self.array[layer][y][x] = Entity.Entity(
                            "", x, y, [system_map.get_tile_image(
                                x, y, layer)], resource_loader, {}, {}
                        )
                    except Exception as er:
                        print(er)
                        self.array[layer][y][x] = None

    def add_tracked_entity(self, entity: Entity, type: str):
        if type == "allies":
            self.allies[entity.properties['name'].value] = entity
            pass
        elif type == "enemies":
            self.enemies[entity.properties['name'].value] = entity
            pass
        elif type == "obsicals":
            self.obsicals[entity.properties['name'].value] = entity
            pass
        else:
            raise Exception("Type is bad")

    def get_net_change(self, location: tuple[int, int]):
        print(((self.allies['player'].properties['x'].value / 32 - location[0]) / 2,
               (self.allies['player'].properties['y'].value / 32 - location[1]) / 2))
        return ((self.allies['player'].properties['x'].value / 32 - location[0]) / 2,
                (self.allies['player'].properties['y'].value / 32 - location[1]) / 2)

    def is_entity_at(self, location: tuple[int, int]):
        for layer in range(self.layers):
            if self.array[layer][location(1)][location(0)] is not None:
                return True

    def get_entity_at(self, location: tuple[int, int]) -> Entity:
        for layer in range(self.layers):
            if self.array[layer][location(1)][location(0)] is not None:
                return self.array[layer][location(1)][location(0)]
