import datetime
import os
import inspect

class Logger:
    def __init__(self, timestamp: bool, filename: str = None):
        self.timestamp = timestamp
        self.filename = filename
        if self.filename == None:
            self.filename = datetime.datetime.now().strftime("%a-%H-%M-%S.log")
        self.logfile = open(self.filename, 'w')

    def write(self, message: str) -> None:
        if self.timestamp:
            self.logfile.write(
                inspect.stack()[1].filename + " - " + datetime.datetime.now().strftime("%a-%H-%M-%S") + ": " + message + "\n")
        else:
            self.logfile.write(inspect.stack()[1].filename + " - " + message + "\n")
