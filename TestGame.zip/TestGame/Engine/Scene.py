from Engine.World import World
import pygame
import abc

from Engine.ResourceLoader import ResourceLoader, MapLoader
from Engine.Input import InputManager
from Engine import Entity


class Scene(abc.ABC):
    def __init__(self, map_name: str, resources: ResourceLoader):
        # change to world map once finished
        map_loader = MapLoader(
            resources.get_resource("maps", map_name))
        layer, width, height = map_loader.generate_data()
        self.map = World(layer, width, height)
        self.map.write_map_data(map_loader.get_map(), resources)
        self.update_camera = True

    def render(self) -> pygame.surface.Surface:
        surface = pygame.Surface((self.map.width * 32, self.map.height * 32))
        for layer in self.map.array:
            for row in layer:
                for entity in row:
                    if entity is not None:
                        entity.properties['sprite'].value.draw(surface)
        for ally in self.map.allies.values():
            ally.properties['sprite'].value.draw(surface)
        for enemy in self.map.enemies.values():
            enemy.properties['sprite'].value.draw(surface)
        for obstical in self.map.obsicals.values():
            obstical.properties['sprite'].value.draw(surface)
        return surface

    @abc.abstractmethod
    def update(self, world_loc: tuple[int, int], resources: ResourceLoader, input: InputManager):
        pass

    def move_entity(self, entity: Entity, loc: tuple):
        if loc[0] * 32 + entity.properties['x'].value < 0 or loc[0] * 32 + entity.properties['x'].value + 32 > self.map.width * 32:
            return False
        if loc[1] * 32 + entity.properties['y'].value < 0 or loc[1] * 32 + entity.properties['y'].value + 32 > self.map.height * 32:
            return False

        for sprite in entity.properties['sprites'].value:
            sprite.rect.x += loc[0] * 32
            sprite.rect.y += loc[1] * 32

        entity.properties['x'].value = entity.properties['x'].value + loc[0] * 32
        entity.properties['y'].value = entity.properties['y'].value + loc[1] * 32

        self.update_camera = True

        return True

    def set_entity_loc(self, entity: Entity, loc: tuple):
        if loc[0] < 0 or loc[0] > self.map.width:
            return False
        if loc[1] < 0 or loc[1] > self.map.height:
            return False

        for sprite in entity.properties['sprites'].value:
            sprite.rect.x = loc[0] * 32
            sprite.rect.y = loc[1] * 32

        entity.properties['x'].value = loc[0] * 32
        entity.properties['y'].value = loc[1] * 32

        self.update_camera = True

        return True
