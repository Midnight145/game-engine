import pygame


class InputManager(object):
    def __init__(self):
        super().__init__()
        self.keys = []
        self.buttons = []
        self.cursor_pos = ()

    def press_key(self, key):
        self.keys.append(key)

    def press_button(self, button):
        self.buttons.append(button)

    def clear_keys(self):
        self.keys.clear()

    def clear_buttons(self):
        self.buttons.clear()

    def key_down(self, key):
        return key in self.keys

    def button_down(self, button):
        return button in self.buttons

    def set_cursor_pos(self, pos):
        self.pos = pos
