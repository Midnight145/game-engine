name str Sword
damage int 4
resources list claymore_2