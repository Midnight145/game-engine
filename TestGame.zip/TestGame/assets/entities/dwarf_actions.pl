can_move_up can_move_up move_up True
can_move_left can_move_left move_left True
can_move_right can_move_right move_right True
can_move_down can_move_down move_down True