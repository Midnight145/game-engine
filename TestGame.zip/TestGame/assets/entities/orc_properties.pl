can_move_up bool False
can_move_left bool False
can_move_down bool False
can_move_right bool False
resources list orc_male