can_move can_move move True
take_damage default_checker take_damage True
is_dead default_checker is_dead True
heal default_checker heal True
drop_weapon default_checker drop_weapon True
set_current_item default_checker set_current_item True