$CharacterName = Read-Host -Prompt "Enter the name of the character you wish to create: "

$PropertiesPath = "./assets/entities/" + $CharacterName + "_properties.pl"
$ActionsPath = "./assets/entities/" + $CharacterName + "_actions.pl"

New-Item -Path $PropertiesPath
New-Item -Path $ActionsPath