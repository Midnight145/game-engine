class Potion:
    def __init__(self, name):
        self.name = name
        self.heal_amount = 10

    
    
