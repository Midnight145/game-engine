import abc

from Engine.Input import InputManager
from Engine.ResourceLoader import ResourceLoader
from Engine.Entity import Entity


class Element(Entity, meta=abc.ABCMeta):
    def __init__(self, name: str, x: int, y: int, images: list, resources: ResourceLoader) -> None:
        properties = {}
        actions = {}

        super().__init__(name, x, y, images, resources, properties, actions)

    @abc.abstractmethod
    def render(self):
        pass

    @abc.abstractmethod
    def update(self, input_manager: InputManager):
        pass
