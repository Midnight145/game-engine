from Engine import Scene
from Engine import Entity

from pathfinding.core.grid import Grid
from pathfinding.finder.a_star import AStarFinder


def pathfind(self, pos1, pos2, scene):
    # returns tuple in format y, x
    def move(scene, path, x, y, lastx=-1, lasty=-1):
        if x - 1 >= 0:
            loc = (x - 1, y)
            if not loc == (lastx, lasty):
                x -= 1
                if int(path[x][y]) == 1:
                    moves.append((x - 1, y))
                    if move(path, x, y, x + 1, y):
                        return True
                elif int(path[x][y]) == 3:
                    moves.append((x - 1, y))
                    return True
                else:
                    x += 1

        if x + 1 <= len(path) - 1:
            loc = (x + 1, y)
            if not loc == (lastx, lasty):
                x += 1
                if int(path[x][y]) == 1:
                    moves.append((x + 1, y))
                    if move(path, x, y, x - 1, y):
                        return True
                elif int(path[x][y]) == 3:
                    moves.append((x + 1, y))
                    return True
                else:
                    x -= 1

        if y - 1 >= 0:
            loc = (x, y - 1)
            if not loc == (lastx, lasty):
                y -= 1
                if int(path[x][y]) == 1:
                    moves.append((x, y - 1))
                    if move(path, x, y, x, y + 1):
                        return True
                elif int(path[x][y]) == 3:
                    moves.append((x, y - 1))
                    return True
                else:
                    y += 1

        if y + 1 <= len(path[0]) - 1:
            loc = (x, y + 1)
            y += 1
            if not loc == (lastx, lasty):
                if int(path[x][y]) == 1:
                    moves.append((x, y + 1))
                    if move(path, x, y, x, y - 1):
                        return True
                elif int(path[x][y]) == 3:
                    moves.append((x, y + 1))
                    return True
                else:
                    y -= 1

    x1, y1 = pos1
    x2, y2 = pos2

    matrix = [[1 for i in range(scene.map.width)]
              for i in range(scene.map.height)]
    for entity in self.scene.obstacles:
        rect = entity.properties["sprites"][0].rect
        matrix[rect.y][rect.x] = 0

    for key, item in scene.enemies.items():
        rect = item.properties["sprites"][0].rect
        matrix[rect.x][rect.y] = 0

    for key, item in scene.allies.items():
        rect = item.properties["sprites"][0].rect
        matrix[rect.x][rect.y] = 0

    grid = Grid(matrix=matrix)
    start = grid.node(y1, x1)
    end = grid.node(y2, x2)

    finder = AStarFinder(diagonal_movement=False)
    path, runs = finder.find_path(start, end, grid)
    lists = [int(x) for x in (i.strip() for i in grid.grid_str(path=path, start=start, end=end, empty_chr='4', path_chr='1',
                                                               block_chr='4', border=False, start_chr='2', end_chr='3').splitlines())]
    moves = []
    move(scene, lists, x1, y1)

    return moves
