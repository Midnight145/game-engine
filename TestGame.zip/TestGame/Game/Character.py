from Engine.Entity import Entity


def take_damage(entity: Entity, amount):
    entity.properties["health"].value -= amount


def attack(attacker: Entity, attackee: Entity):
    attackee.actions["take_damage"].action(attackee, attacker.properties["weapon"].value.actions["get_damage"].action())


def heal(entity: Entity, amount: int):
    entity.properties['health'].value += amount


def is_dead(entity: Entity):
    return not entity.properties["health"].value > 0


def drop_weapon(entity: Entity):
    return entity.properties["weapon"].value


def add_item(player: Entity, item: Entity):
    if player.properties["inventory"].value[0] == 0:
        player.properties["inventory"].value.clear()
    player.properties["inventory"].value.append(item)


def remove_item(player: Entity, item: Entity):
    try:
        player.properties["inventory"].value.remove(item)
    except Exception:
        return


def get_current_item(player: Entity, index: int):
    return player.properties["inventory"].value[player.properties["current_item"].value]


def set_current_item(player: Entity, index: int):
    player.properties["current_item"].value = index


def set_weapon(entity: Entity, item: item):
    entity.properties["weapon"].value = weapon