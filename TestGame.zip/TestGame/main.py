from Engine.UI.Element import Window
import Engine
import pygame
import random

import Game.AI_methods

from Engine.Input import InputManager
from Engine.ResourceLoader import ResourceLoader
from Engine.Entity import Entity
import Engine.Application

class Test(Engine.Scene.Scene):
    def __init__(self, resources: ResourceLoader):
        super().__init__("arena-1", resources)
        self.map.add_tracked_entity(
            Entity(
                "player", 31, 31, [], resources, {}, {}
            ),
            "allies"
        )

    def update(self, world_loc: tuple[int, int], resource_loader: ResourceLoader, input_handler: InputManager):
        if input_handler.key_down(pygame.K_w):
            # translate mouse coords to tile over
            self.move_entity(self.map.allies['player'], (0, -1))
        if input_handler.key_down(pygame.K_a):
            # translate mouse coords to tile over
            self.move_entity(self.map.allies['player'], (-1, 0))
        if input_handler.key_down(pygame.K_s):
            # translate mouse coords to tile over
            self.move_entity(self.map.allies['player'], (0, 1))
        if input_handler.key_down(pygame.K_d):
            # translate mouse coords to tile over
            self.move_entity(self.map.allies['player'], (1, 0))

            

if __name__ == "__main__":
    app = Engine.Application.Application("Hello world", (10 * 32, 10 * 32))
    app.load_scene(Test(app.resource_manager))
    app()
